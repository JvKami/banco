package com.example.pyun.demo_banco;

public class Usuario {

    public int id;
    public String conta;
    public String agencia;
    public String nome;
    public String sobrenome;
    public String cpf;
    public String rg;
    public String sexo;
}
