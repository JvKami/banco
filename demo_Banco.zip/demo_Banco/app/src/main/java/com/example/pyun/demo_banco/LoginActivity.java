package com.example.pyun.demo_banco;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

public class LoginActivity extends AppCompatActivity {

    EditText Conta, Senha;
    Spinner Agencia;

    ArrayList<Usuario> lista;
    ArrayAdapter<Usuario> adapter;

    String conta = "";
    String agencia = "";
    String senha = "";

    String contaUser, agenciaUser, nomeUser, sobrenomeUser, cpfUser, rgUser, sexoUser;

    boolean erro = true;

    Usuario user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Conta = (EditText) findViewById(R.id.txtConta);
        Senha = (EditText) findViewById(R.id.txtSenha);

        Agencia = (Spinner) findViewById(R.id.spAgencia);
        ArrayAdapter<CharSequence> adp;
        adp = ArrayAdapter.createFromResource(this, R.array.agencia, android.R.layout.simple_spinner_item);
        adp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Agencia.setAdapter(adp);
    }

    //FRESCURA
    @Override
    public void onBackPressed(){
        System.exit(0);
    }

    //CLICK LOGIN
    public void login(View v) {
        conta = Conta.getText().toString();
        senha = Senha.getText().toString();
        agencia = Agencia.getSelectedItem().toString();


        if(!(conta.equals("") || senha.equals("") || agencia.equals(""))){
            Connection conn = new Connection();
            conn.execute();

            if(erro == true){
                Toast.makeText(this, "Erro de conexão", Toast.LENGTH_SHORT).show();

                Toast.makeText(this, contaUser + "\n" + agenciaUser, Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(this, contaUser + "\n" + agenciaUser, Toast.LENGTH_SHORT).show();

                Intent i = new Intent(this, MainActivity.class);
                startActivity(i);
            }

        }else{
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
        }
    }

    //BANCO DE DADOS
    class Connection extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            BufferedReader reader;
            HttpsURLConnection conex;

            try {
                URL url = new URL("https://safewalk.tech/_site_/android/select.php?conta=" + conta + "&agencia=" + agencia + "&senha=" + senha);

                conex = (HttpsURLConnection) url.openConnection();
                conex.setRequestMethod("GET");
                conex.connect();

                InputStream open = conex.getInputStream();
                reader = new BufferedReader(new InputStreamReader(open));

                String linha;
                StringBuffer result = new StringBuffer();

                if ((linha = reader.readLine()) != null) {
                    result.append(linha);
                }

                erro = false;

                return result.toString();

            } catch (Exception ex) {
                erro = true;

                return "Erro de conexão com o servidor";
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {

                    JSONObject x = new JSONObject(s);

                    user = new Usuario();
                    user.id = x.getInt("id");
                    user.agencia = x.getString("agencia");
                    user.conta = x.getString("conta");
                    user.nome = x.getString("nome");
                    user.sobrenome = x.getString("sobrenome");
                    user.cpf = x.getString("cpf");
                    user.rg = x.getString("rg");
                    user.sexo = x.getString("sexo");

                    contaUser = user.conta;
                    agenciaUser = user.agencia;
                    nomeUser = user.nome;
                    sobrenomeUser = user.sobrenome;
                    cpfUser = user.cpf;
                    rgUser = user.rg;
                    sexoUser = user.sexo;

                    erro = false;


            } catch (JSONException e) {
                erro = true;

                contaUser = null;
                agenciaUser = null;
                nomeUser = null;
                sobrenomeUser = null;
                cpfUser = null;
                rgUser = null;
                sexoUser = null;

                e.printStackTrace();
            }
        }
    }
}
